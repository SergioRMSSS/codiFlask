from flask import Flask, render_template, redirect, url_for, request
app = Flask(__name__)

@app.route("/")
def helloold():
    return "Hello World! KLK CON KLK"
@app.route("/my/secret/page")
def secret():
    return "Shh!"

@app.route("/user/<username>")
def user_page(username):
    return f"Welcome, {username}!"

@app.route("/blog/post/<int:post_id>")
def show_post(post_id):
    return f"This is the page for post # {post_id}"

@app.route("/parellsenar/<num>")
def parellsenar(num):
    if int(num) % 2 == 0:
        return f"El numero {num} es par"
    else: 
        return f"El numero {num} es impar"

@app.route('/hello/')
@app.route('/hello/<name>')
def hello(name=None):
    return render_template('hello.html', person=name)



@app.route('/exito/<nombre>/<int:edad>/<edadfinal>')
def exito(nombre, edad, edadfinal):
    return render_template('zizi.html', nombre=nombre, edad=edad, edadfinal=edadfinal)

@app.route('/formedat100',methods = ['POST', 'GET'])
def formedat100():
   if request.method == 'POST':
      nom = request.form['nom']
      edat = request.form['edat']
      finalage = 100 - int(edat) + 2026
      return redirect(url_for('exito' , nombre = nom , edad = edat , edadfinal = finalage))
   else:
      return render_template("formedat.html")



@app.route('/success/<name>')
def success(name):
   return 'welcome %s' % name

@app.route('/login',methods = ['POST', 'GET'])
def login():
   if request.method == 'POST':
      user = request.form['nm']
      return redirect(url_for('success',name = user))
   else:
      return render_template("login.html")
   


@app.route('/edat100/<nom>/<int:edat>/')
def edat(nom , edat):
    finalage= 100 - edat + 2026
    return render_template('zizi.html', nombre=nom, edad=edat, edadfinal=finalage)