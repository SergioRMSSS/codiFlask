# Este ejercicio es igual que el 7.1 pero contra un bot
import random

objetos = ("piedra","papel","tijera") #Aqui uso una tupla para que sea diferente y en el w3 pone que es mas rapida y al ser inmutable y solo existir esas 3 opciones nos aseguramos de que no cambien

jugador = input("Nombre del jugador: ")



while True:
    seleccion = input("Escoje piedra, papel o tijera: ")
    bot = random.choice(objetos)
    print (f"El bot ha elegido: {bot.upper()} ")
    if seleccion.lower() in objetos:
        if seleccion == bot:
            print ("EMPATE")
        elif seleccion.lower() == "piedra" and bot == "tijera":
            print(f"EL JUGADOR {jugador} GANA")
        elif seleccion.lower() == "papel" and bot == "piedra":
            print(f"EL JUGADOR {jugador} GANA")
        elif seleccion.lower () == "tijera" and bot == "papel":
            print(f"EL JUGADOR {jugador} GANA")
        else:
            print("EL BOT GANA")
    else:
        print("SELECCION INCORRECTA")
    
    seguir = input("Quieres volver a jugar s/n: ")
    if seguir.lower() == "n" or seguir.lower() == "no":
        break