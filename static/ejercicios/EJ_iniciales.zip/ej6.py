palabra = input("Dime una palabra para comprobar si es palindroma: ")

if palabra.lower() == palabra.lower()[::-1]:
    print(f"La palabra {palabra} es palindroma")
else:
    print(f"La palabra {palabra} no es palindroma")
