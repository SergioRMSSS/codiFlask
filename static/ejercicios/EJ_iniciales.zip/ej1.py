name = input("Cual es tu nombre: ")
age = int(input("Cual es tu edad: "))
finalage= 100 - age + 2026

if age > 100:
    print("Ya tienes 100 años, que sean muchos mas")
else :
    print(f"Tu nombre es {name} y cumpliras los 100 años en {finalage}")