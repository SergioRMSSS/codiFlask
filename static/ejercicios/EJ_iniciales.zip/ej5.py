edadalum = [2006,2003,2005,2002,2001,2004]
añosalum = []

for i in edadalum:
    añosalum.append(2026 - i)

print (añosalum)