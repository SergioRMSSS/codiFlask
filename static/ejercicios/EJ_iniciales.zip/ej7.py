jugador1 = input("Nombre del jugador 1: ")
jugador2 = input("Nombre del jugador 2: ")

objetos = ["piedra", "papel", "tijera"]

while True:
    seleccion1 = input(f"{jugador1} escoje (Piedra, papel o tijera): ")
    seleccion2 = input(f"{jugador2} escoje (Piedra, papel o tijera): ")
    if seleccion1.lower() in objetos and seleccion2.lower() in objetos:
        if seleccion1.lower() == seleccion2.lower():
            print("EMPATE")
        elif seleccion1.lower() == "piedra" and seleccion2 == "tijera":
            print(f"EL JUGADOR {jugador1} GANA")
        elif seleccion1.lower() == "papel" and seleccion2 == "piedra":
            print(f"EL JUGADOR {jugador1} GANA")
        elif seleccion1.lower() == "tijera" and seleccion2 == "papel":
            print(f"EL JUGADOR {jugador1} GANA")
        else:
            print(f"EL JUGADOR {jugador2} GANA")
    else:
        print("Seleccion incorrecta")

    seguir = input("Quieres volver a jugar s/n: ")
    if seguir.lower() == "n" or seguir.lower () == 'no':
        print("GRACIAS POR JUGAR")
        break
