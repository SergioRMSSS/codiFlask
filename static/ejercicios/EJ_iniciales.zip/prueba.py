x = range(1,10)
y = int(input("Pon un numero anda: "))

if y in x:
    print("BIEN BIEN")
else:
    print("MAL MAL")
