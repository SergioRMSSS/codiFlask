diccionario = { 
    "SERGIO": "sergio@proven.cat", 
    "ARMAN": "arman@proven.cat", 
    "HANS": "hans@proven.cat", 
    "DIEGO": "diego@proven.cat", 
    "JAUME": "jaume@proven.cat", 
    "JOSE": "jose@proven.cat", 
    "JOEL": "joel@proven.cat", 
    "OSCAR": "oscar@proven.cat", 
    "JUANMI": "juanmi@proven.cat", 
    "MYRNA": "myrna@proven.cat", 
    "FRED": "fred@proven.cat" 
}

nombre = input("Dime el nombre del alumno para buscar su correo: ")
x = diccionario[nombre.upper()]
print(x)