numeros = [3,5,7,66,1,2,0,80,10,11,23,25]

for i in numeros:
    if i > 5:
        print (f"{i} es mayor que 5")