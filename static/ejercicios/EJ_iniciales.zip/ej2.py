numero = int(input("Dime un numero: "))

if numero % 2 == 0:
    print(f"El numero {numero} es par")
else: 
    print(f"El numero {numero} es impar")

if numero % 4 == 0:
    print(f"Ademas el numero {numero} es multiplo de 4")

numero2 = int(input("Dime otro numero: "))

if numero % numero2 == 0:
    print (f"El numero {numero} es divisible por {numero2}")
else:
    print(f"El numero {numero} NO es divisible por {numero2}")