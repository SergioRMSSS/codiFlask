import diccionario

nombre = input("Nombre del alumno para buscar su correo: ")
if nombre.upper() in diccionario.diccionario:
    a = diccionario.diccionario[nombre.upper()]
    print(a)
else:
    print(f"No hemos encontrado a {nombre.upper()} en nuestro disccionario ;( ")