import random

x = range(1,10)
numsecreto = random.randint(1,9)
intentos = 0

print("En este juego tendras que adivinar un numero entre 1-9, escribe \"exit\" para salir")

while True:
    numero = input("Intenta hacertar un numero entre 1-9: ")
    intentos += 1
    if numero.lower() == "exit":
        print("Gracias por jugar :) ")
        break
    if int(numero) in x:
        if numsecreto == int(numero):
            print("Felicidades lo has acertado🥳🥳 ")
            print(f"Lo has logrado en {intentos} intentos")
            break
        else:
            print("Lo siento has fallado ;( ")
    else:
        print("Valor introducido no es valido")
