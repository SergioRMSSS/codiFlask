list2 = [1,11,2,55,4,99,6]
list1 = [2,4,6,7,11]

for i in list1:
    for x in list2:
        if x == i:
            print(x)